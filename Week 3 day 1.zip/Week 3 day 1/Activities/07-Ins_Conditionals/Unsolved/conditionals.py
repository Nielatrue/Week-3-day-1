x = 1
y = 10

# Checks if one value is equal to another

# Checks if one value is NOT equal to another

# Checks if one value is less than another

# Checks if one value is greater than another

# Checks if a value is greater than or equal to another

# Checks for two conditions to be met using "and"

# Checks if either of two conditions is met

# Nested if statements
